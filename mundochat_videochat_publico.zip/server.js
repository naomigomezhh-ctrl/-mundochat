const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const rooms = new Map();

app.use(express.static(path.join(__dirname, "public")));

function getRooms() {
  return [...rooms.entries()].map(([id, room]) => ({
    id,
    name: room.name,
    topic: room.topic,
    users: room.users.size
  }));
}

io.on("connection", socket => {
  socket.emit("rooms", getRooms());

  socket.on("create-room", ({ name, topic, nickname }) => {
    const id = Math.random().toString(36).slice(2, 9);
    rooms.set(id, {
      name: String(name || "Sala pública").slice(0, 60),
      topic: String(topic || "Conversación").slice(0, 40),
      users: new Map()
    });
    joinRoom(socket, id, nickname);
    io.emit("rooms", getRooms());
  });

  socket.on("join-room", ({ roomId, nickname }) => {
    if (!rooms.has(roomId)) return socket.emit("error-message", "La sala ya no existe.");
    joinRoom(socket, roomId, nickname);
  });

  socket.on("signal", ({ to, data }) => {
    io.to(to).emit("signal", { from: socket.id, data });
  });

  socket.on("chat-message", message => {
    const roomId = socket.data.roomId;
    if (!roomId) return;
    const room = rooms.get(roomId);
    if (!room) return;
    const user = room.users.get(socket.id);
    io.to(roomId).emit("chat-message", {
      nickname: user?.nickname || "Usuario",
      message: String(message).slice(0, 500)
    });
  });

  socket.on("disconnect", () => {
    const roomId = socket.data.roomId;
    if (!roomId) return;
    const room = rooms.get(roomId);
    if (!room) return;
    room.users.delete(socket.id);
    socket.to(roomId).emit("peer-left", socket.id);
    if (room.users.size === 0) rooms.delete(roomId);
    io.emit("rooms", getRooms());
  });
});

function joinRoom(socket, roomId, nickname) {
  const room = rooms.get(roomId);
  if (!room) return;
  if (socket.data.roomId) leaveCurrentRoom(socket);

  socket.join(roomId);
  socket.data.roomId = roomId;
  room.users.set(socket.id, {
    nickname: String(nickname || "Invitado").slice(0, 30)
  });

  socket.emit("room-info", {
    id: roomId,
    name: room.name,
    topic: room.topic,
    peers: [...room.users.entries()]
      .filter(([id]) => id !== socket.id)
      .map(([id, u]) => ({ id, nickname: u.nickname }))
  });

  socket.to(roomId).emit("peer-joined", {
    id: socket.id,
    nickname: room.users.get(socket.id).nickname
  });
  io.emit("rooms", getRooms());
}

function leaveCurrentRoom(socket) {
  const roomId = socket.data.roomId;
  const room = rooms.get(roomId);
  if (!room) return;
  room.users.delete(socket.id);
  socket.leave(roomId);
  socket.to(roomId).emit("peer-left", socket.id);
  socket.data.roomId = null;
  if (room.users.size === 0) rooms.delete(roomId);
  io.emit("rooms", getRooms());
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`MundoChat: http://localhost:${PORT}`));