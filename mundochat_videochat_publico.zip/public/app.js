const socket = io();
const $ = id => document.getElementById(id);

let localStream = null;
let roomId = null;
let nickname = "";
const peers = new Map();

const rtcConfig = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };

function show(id) {
  $("home").classList.toggle("hidden", id !== "home");
  $("room").classList.toggle("hidden", id !== "room");
}

function renderRooms(rooms) {
  $("roomCount").textContent = `${rooms.length} sala${rooms.length === 1 ? "" : "s"}`;
  $("rooms").innerHTML = "";
  if (!rooms.length) {
    $("rooms").innerHTML = '<div class="empty">No hay salas todavía. ¡Crea la primera!</div>';
    return;
  }
  rooms.forEach(r => {
    const card = document.createElement("div");
    card.className = "room-card";
    card.innerHTML = `<h3>${escapeHtml(r.name)}</h3>
      <p>🏷️ ${escapeHtml(r.topic)}<br>👥 ${r.users} participante${r.users === 1 ? "" : "s"}</p>
      <button class="primary join">Entrar a la sala</button>`;
    card.querySelector(".join").onclick = () => {
      $("joinTitle").textContent = `Entrar: ${r.name}`;
      $("joinDialog").showModal();
      $("joinForm").onsubmit = e => {
        e.preventDefault();
        nickname = $("joinNickname").value.trim();
        if (!nickname) return;
        $("joinDialog").close();
        socket.emit("join-room", { roomId: r.id, nickname });
      };
    };
    $("rooms").appendChild(card);
  });
}

$("newRoomBtn").onclick = () => $("roomDialog").showModal();
$("cancelDialog").onclick = () => $("roomDialog").close();
$("cancelJoin").onclick = () => $("joinDialog").close();

$("roomForm").onsubmit = e => {
  e.preventDefault();
  nickname = $("nickname").value.trim();
  socket.emit("create-room", {
    name: $("roomTitle").value.trim(),
    topic: $("topic").value,
    nickname
  });
  $("roomDialog").close();
};

socket.on("rooms", renderRooms);

socket.on("room-info", async info => {
  roomId = info.id;
  $("roomName").textContent = info.name;
  $("roomTopic").textContent = `🏷️ ${info.topic}`;
  show("room");
  await startMedia();
  for (const peer of info.peers) await createOffer(peer.id, peer.nickname);
  updateCount();
});

socket.on("peer-joined", async peer => {
  await createOffer(peer.id, peer.nickname);
  updateCount();
});

socket.on("signal", async ({ from, data }) => {
  let pc = peers.get(from)?.pc;
  if (!pc) pc = makePeer(from, "Participante");
  if (data.description) {
    await pc.setRemoteDescription(data.description);
    if (data.description.type === "offer") {
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket.emit("signal", { to: from, data: { description: pc.localDescription } });
    }
  }
  if (data.candidate) {
    try { await pc.addIceCandidate(data.candidate); } catch {}
  }
});

socket.on("peer-left", id => {
  const p = peers.get(id);
  if (p) p.pc.close();
  peers.delete(id);
  document.getElementById(`video-${id}`)?.remove();
  updateCount();
});

socket.on("chat-message", ({ nickname, message }) => {
  const div = document.createElement("div");
  div.className = "msg";
  div.innerHTML = `<b>${escapeHtml(nickname)}</b><div>${escapeHtml(message)}</div>`;
  $("messages").appendChild(div);
  $("messages").scrollTop = $("messages").scrollHeight;
});

socket.on("error-message", alert);

async function startMedia() {
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video:true, audio:true });
    addVideo("local", localStream, `${nickname} (tú)`);
  } catch {
    alert("Necesitas permitir cámara y micrófono para participar por video.");
  }
}

function makePeer(id, name) {
  if (peers.has(id)) return peers.get(id).pc;
  const pc = new RTCPeerConnection(rtcConfig);
  localStream?.getTracks().forEach(t => pc.addTrack(t, localStream));
  pc.onicecandidate = e => {
    if (e.candidate) socket.emit("signal", { to:id, data:{ candidate:e.candidate } });
  };
  pc.ontrack = e => addVideo(id, e.streams[0], name);
  peers.set(id, { pc, name });
  return pc;
}

async function createOffer(id, name) {
  const pc = makePeer(id, name);
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  socket.emit("signal", { to:id, data:{ description:pc.localDescription } });
}

function addVideo(id, stream, name) {
  let card = document.getElementById(`video-${id}`);
  if (!card) {
    card = document.createElement("div");
    card.className = "video-card";
    card.id = `video-${id}`;
    card.innerHTML = `<video autoplay playsinline></video><span class="video-label"></span>`;
    $("videos").appendChild(card);
  }
  card.querySelector("video").srcObject = stream;
  card.querySelector(".video-label").textContent = name;
  updateCount();
}

function updateCount() {
  $("participantCount").textContent = `${peers.size + (localStream ? 1 : 0)} participante${peers.size === 0 ? "" : "s"}`;
}

$("micBtn").onclick = () => {
  const t = localStream?.getAudioTracks()[0];
  if (!t) return;
  t.enabled = !t.enabled;
  $("micBtn").textContent = t.enabled ? "🎤 Micrófono" : "🔇 Micrófono";
};
$("camBtn").onclick = () => {
  const t = localStream?.getVideoTracks()[0];
  if (!t) return;
  t.enabled = !t.enabled;
  $("camBtn").textContent = t.enabled ? "📷 Cámara" : "🚫 Cámara";
};

$("chatForm").onsubmit = e => {
  e.preventDefault();
  const input = $("chatInput");
  if (input.value.trim()) socket.emit("chat-message", input.value.trim());
  input.value = "";
};

async function leave() {
  localStream?.getTracks().forEach(t => t.stop());
  peers.forEach(p => p.pc.close());
  peers.clear();
  document.querySelectorAll(".video-card").forEach(e => e.remove());
  roomId = null;
  show("home");
}
$("leaveBtn").onclick = leave;
$("backBtn").onclick = leave;

$("copyBtn").onclick = async () => {
  const url = `${location.origin}/?room=${roomId}`;
  try { await navigator.clipboard.writeText(url); alert("Enlace de la sala copiado."); }
  catch { prompt("Copia este enlace:", url); }
};

const params = new URLSearchParams(location.search);
const requestedRoom = params.get("room");
if (requestedRoom) {
  $("joinNickname").value = "";
  $("joinDialog").showModal();
  $("joinForm").onsubmit = e => {
    e.preventDefault();
    nickname = $("joinNickname").value.trim();
    if (!nickname) return;
    $("joinDialog").close();
    socket.emit("join-room", { roomId: requestedRoom, nickname });
  };
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}